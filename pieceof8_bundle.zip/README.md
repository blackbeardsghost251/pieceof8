# pieceof8

A Bash Bunny-inspired offensive toolkit for the Raspberry Pi Zero 2 W  
Composite USB HID (keyboard) + RNDIS (Ethernet over USB) with a modular, web-managed payload system.

---

## Features

- **Composite USB Gadget:** Presents as both keyboard and RNDIS Ethernet.
- **Modular Payloads:** Drop-in folders with payload logic, meta, and scripts.
- **Web UI:** Select payloads, generate new HID payloads, and download exfiltrated data.
- **Exfil Storage:** Data from payloads is stored for later download.
- **Example Payloads:** PoisonTap-like attacks, keylogger, staged droppers, and more.

---

## Hardware Requirements

- Raspberry Pi Zero 2 W (or Pi Zero)
- Micro SD card (8GB+)
- Micro USB OTG cable

---

## Quick Start

### 1. Flash Raspberry Pi OS Lite

- Download [Raspberry Pi OS Lite](https://downloads.raspberrypi.org/raspios_lite_armhf_latest)
- Flash using [Raspberry Pi Imager](https://www.raspberrypi.com/software/) or [Balena Etcher](https://www.balena.io/etcher/)

### 2. Prepare for Headless Boot

- Mount the flashed boot partition.
- Add a blank file named `ssh` to enable SSH.
- (Optional) Add `wpa_supplicant.conf` for WiFi.

### 3. Boot and SSH In

- Default user: `pi`
- Default password: `raspberry`

### 4. Clone and Install

```bash
git clone https://github.com/yourusername/pieceof8.git
cd pieceof8
sudo ./install.sh
```

### 5. Reboot

```bash
sudo reboot
```

### 6. Use the Web UI

- Connect your Pi Zero 2 W to a computer via USB.
- Browse to [http://172.16.42.1:8080](http://172.16.42.1:8080) (or Pi’s IP) to manage payloads.

---

## Directory Structure

```
pieceof8/
├── install.sh
├── payloads/
│   ├── autorun.sh
│   ├── selected
│   ├── web_selector.py
│   ├── web_selector.service
│   ├── hid_open_url/
│   ├── rndis_keylogger/
│   ├── poisontap_basic/
│   ├── poisontap_serviceworker/
│   ├── poisontap_cookiejack/
│   ├── ... (more payloads)
├── exfil/   # Exfiltrated data
├── usb-gadget.service
├── setup_usb_gadget.sh
├── payloads.service
```

---

## Example Payloads

- **hid_open_url:** Types a phishing URL in the default browser.
- **rndis_keylogger:** Drops and runs a PowerShell keylogger, exfiltrates keystrokes back to the Pi.
- **poisontap_basic:** PoisonTap-like default gateway/DNS, serves malicious web/JS, exfiltrates cookies.
- **poisontap_serviceworker:** Registers a persistent malicious service worker in the browser.
- **poisontap_cookiejack:** Steals cookies via JS and POSTs to the Pi.
- **hid_exfil:** Types out contents of an exfiltrated secrets file as keyboard.
- **http_exfil:** Hosts all files in `/home/pi/exfil/` for download over the network.

See individual payload folders for `meta.json` and `run.sh`.

---

## Web UI Features

- **Payload Selection:** Choose which payload runs on next boot.
- **Payload Generator:** Create new keystroke (HID) payloads.
- **Exfil Download:** Download files exfiltrated from payloads.
- **Descriptions:** See what each payload does before activating.

---

## Adding New Payloads

1. Create a new folder in `payloads/`.
2. Add a `meta.json` (see examples) and a `run.sh`.
3. (Optional) Add helper scripts or data.
4. Your payload will appear in the web UI.

---

## Ethical Use

This toolkit is for authorized security testing, research, and education **only**.  
Do **not** use on systems you do not own or do not have explicit permission to test.

---

## Credits

Heavily inspired by [Bash Bunny](https://www.hak5.org/products/bash-bunny), [PoisonTap](https://github.com/samyk/poisontap), and the broader offensive security community.

---

## License

MIT License