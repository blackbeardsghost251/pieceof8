#!/bin/bash
# Bash Bunny Payload GUI Selector

PAYLOAD_DIR="/home/pi/payloads"
SELECTED_FILE="$PAYLOAD_DIR/selected"

# Build list of payloads
PAYLOADS=($(find "$PAYLOAD_DIR" -maxdepth 1 -mindepth 1 -type d -printf "%f\n" | sort))

if [ ${#PAYLOADS[@]} -eq 0 ]; then
    yad --info --title="No Payloads" --text="No payloads found in $PAYLOAD_DIR."
    exit 1
fi

# Let user pick one
SELECTED=$(yad --list --title="Select Payload" --column="Payload" "${PAYLOADS[@]}" --height=300 --width=300 --center --button=OK:0 --button=Cancel:1)

if [ $? -eq 0 ] && [ -n "$SELECTED" ]; then
    # YAD returns first column as "Payload|"
    CHOICE=$(echo "$SELECTED" | awk -F'|' '{print $1}' | head -n1)
    echo "$CHOICE" > "$SELECTED_FILE"
    yad --info --title="Payload Selected" --text="Selected payload: $CHOICE"
else
    yad --info --title="No Selection" --text="No payload selected."
fi