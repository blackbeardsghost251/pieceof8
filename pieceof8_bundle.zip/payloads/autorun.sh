#!/bin/bash
# Main autorun script (Bash Bunny style)

PAYLOAD_DIR="$(cat /home/pi/payloads/selected 2>/dev/null || echo 'hid_open_url')"
PAYLOAD_PATH="/home/pi/payloads/${PAYLOAD_DIR}"

if [ ! -d "$PAYLOAD_PATH" ]; then
  echo "[!] Payload directory $PAYLOAD_PATH not found."
  exit 1
fi

echo "[*] Running payload: $PAYLOAD_DIR"
cd "$PAYLOAD_PATH"
exec ./run.sh