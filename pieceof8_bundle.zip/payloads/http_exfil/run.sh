#!/bin/bash
sudo ifconfig usb0 172.16.0.1 netmask 255.255.255.0 up
sudo systemctl stop dnsmasq || true
echo -e "interface=usb0\ndhcp-range=172.16.0.10,172.16.0.20,255.255.255.0,24h" | sudo tee /etc/dnsmasq.d/usb0.conf
sudo systemctl restart dnsmasq
cd /home/pi/exfil
python3 -m http.server 8081