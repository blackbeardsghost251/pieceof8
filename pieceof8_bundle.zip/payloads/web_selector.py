import os
import json
from flask import Flask, render_template_string, request, redirect, url_for, send_from_directory

PAYLOADS_DIR = "/home/pi/payloads"
SELECTED_FILE = os.path.join(PAYLOADS_DIR, "selected")
EXFIL_DIR = "/home/pi/exfil"

app = Flask(__name__)

@app.route("/")
def index():
    payloads = []
    for d in sorted(os.listdir(PAYLOADS_DIR)):
        payload_path = os.path.join(PAYLOADS_DIR, d)
        if os.path.isdir(payload_path) and d not in ("__pycache__",):
            meta_path = os.path.join(payload_path, "meta.json")
            if os.path.exists(meta_path):
                with open(meta_path) as f:
                    meta = json.load(f)
            else:
                meta = {"name": d, "description": ""}
            payloads.append({"dir": d, **meta})
    try:
        with open(SELECTED_FILE) as f:
            selected = f.read().strip()
    except FileNotFoundError:
        selected = ""
    exfil_files = []
    try:
        for f in os.listdir(EXFIL_DIR):
            size = os.path.getsize(os.path.join(EXFIL_DIR, f))
            exfil_files.append({"name": f, "size": size})
    except FileNotFoundError:
        pass
    return render_template_string("""
    <h2>Payload Selector</h2>
    <a href="{{ url_for('generate') }}">[Generate New HID Payload]</a><br><br>
    <form method="post" action="{{ url_for('select') }}">
        <select name="payload">
        {% for p in payloads %}
            <option value="{{p.dir}}" {% if p.dir==selected %}selected{% endif %}>{{p.name}} - {{p.description}}</option>
        {% endfor %}
        </select>
        <input type="submit" value="Activate">
    </form>
    <p>Current payload: <b>{{selected}}</b></p>
    <h3>Exfiltrated Files</h3>
    <ul>
    {% for f in exfil_files %}
      <li><a href="{{ url_for('download_exfil', filename=f.name) }}">{{f.name}}</a> ({{f.size}} bytes)</li>
    {% endfor %}
    </ul>
    """, payloads=payloads, selected=selected, exfil_files=exfil_files)

@app.route("/select", methods=["POST"])
def select():
    payload = request.form.get("payload")
    if payload:
        with open(SELECTED_FILE, "w") as f:
            f.write(payload)
    return redirect(url_for("index"))

@app.route("/exfil/<filename>")
def download_exfil(filename):
    return send_from_directory(EXFIL_DIR, filename, as_attachment=True)

@app.route("/generate", methods=["GET", "POST"])
def generate():
    if request.method == "POST":
        payload_name = request.form.get("payload_name", "generated_payload")
        description = request.form.get("description", "")
        keystrokes = request.form.get("keystrokes", "")
        payload_dir = os.path.join(PAYLOADS_DIR, payload_name.replace(" ", "_"))
        os.makedirs(payload_dir, exist_ok=True)
        # meta.json
        from datetime import datetime
        with open(os.path.join(payload_dir, "meta.json"), "w") as f:
            f.write(json.dumps({
                "name": payload_name,
                "description": description,
                "author": os.getenv("USER", "unknown"),
                "created": datetime.now().strftime("%Y-%m-%d")
            }, indent=2))
        # run.sh
        with open(os.path.join(payload_dir, "run.sh"), "w") as f:
            f.write(f"#!/bin/bash\npython3 send_keys.py {json.dumps(keystrokes)}\n")
        # send_keys.py
        send_keys_py = os.path.join(payload_dir, "send_keys.py")
        with open(os.path.join(PAYLOADS_DIR, "hid_open_url/send_keys.py")) as src, open(send_keys_py, "w") as dst:
            dst.write(src.read())
        os.chmod(os.path.join(payload_dir, "run.sh"), 0o755)
        return redirect(url_for("index"))
    return render_template_string("""
    <h2>Generate HID Payload</h2>
    <form method="post">
        Name: <input type="text" name="payload_name" required><br>
        Description: <br><textarea name="description" cols="40" rows="2"></textarea><br>
        Keystrokes to send:<br>
        <textarea name="keystrokes" cols="40" rows="3"></textarea><br>
        <input type="submit" value="Create Payload">
    </form>
    <p><a href="{{ url_for('index') }}">Back to selector</a></p>
    """)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)