import sys
import time

KEYMAP = {
    'A': 0x04, 'B': 0x05, 'C': 0x06, 'D': 0x07, 'E': 0x08, 'F': 0x09,
    'G': 0x0a, 'H': 0x0b, 'I': 0x0c, 'J': 0x0d, 'K': 0x0e, 'L': 0x0f,
    'M': 0x10, 'N': 0x11, 'O': 0x12, 'P': 0x13, 'Q': 0x14, 'R': 0x15,
    'S': 0x16, 'T': 0x17, 'U': 0x18, 'V': 0x19, 'W': 0x1a, 'X': 0x1b,
    'Y': 0x1c, 'Z': 0x1d, '1': 0x1e, '2': 0x1f, '3': 0x20, '4': 0x21,
    '5': 0x22, '6': 0x23, '7': 0x24, '8': 0x25, '9': 0x26, '0': 0x27,
    ' ': 0x2c, '\n': 0x28, '.': 0x37, ',': 0x36
}
SHIFT = 0x02

def send_key(dev, code, mod=0):
    report = bytes([mod, 0, code, 0, 0, 0, 0, 0])
    dev.write(report)
    dev.write(b'\x00\x00\x00\x00\x00\x00\x00\x00')

def send_string(s):
    with open("/dev/hidg0", "wb") as dev:
        for ch in s:
            if ch.isupper():
                send_key(dev, KEYMAP.get(ch.upper(), 0), SHIFT)
            elif ch in KEYMAP:
                send_key(dev, KEYMAP[ch])
            elif ch == '\n':
                send_key(dev, KEYMAP['\n'])
            else:
                continue
            time.sleep(0.1)

if __name__ == "__main__":
    send_string(sys.argv[1])