#!/bin/bash
# Payload 1: Simple HID hello message

for i in {1..10}; do
  [ -e /dev/hidg0 ] && break
  sleep 1
done

python3 send_keys.py "Hello from Pi Zero 2 W!\n"