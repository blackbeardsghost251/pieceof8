#!/bin/bash
sleep 2
python3 send_keys.py 'https://evil.com\n'
sleep 1