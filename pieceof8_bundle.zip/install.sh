#!/bin/bash
set -e

echo "[*] Installing dependencies..."
sudo apt update
sudo apt -y install python3 python3-pip git screen usbutils net-tools dnsmasq

echo "[*] Enabling SSH..."
sudo systemctl enable ssh
sudo systemctl start ssh

echo "[*] Ensuring dwc2 and libcomposite enabled..."
if ! grep -q "^dtoverlay=dwc2" /boot/config.txt; then
  echo "dtoverlay=dwc2" | sudo tee -a /boot/config.txt
fi
for mod in dwc2 libcomposite; do
  if ! grep -q "^$mod" /etc/modules; then
    echo "$mod" | sudo tee -a /etc/modules
  fi
done

echo "[*] Setting up USB gadget systemd service..."
sudo cp usb-gadget.service /etc/systemd/system/
sudo mkdir -p /opt/usb-gadget
sudo cp setup_usb_gadget.sh /opt/usb-gadget/setup.sh
sudo chmod +x /opt/usb-gadget/setup.sh
sudo systemctl enable usb-gadget.service

echo "[*] Setting up payload autorun service..."
sudo cp payloads/autorun.sh /home/pi/payloads/autorun.sh
sudo chmod +x /home/pi/payloads/autorun.sh
sudo cp payloads.service /etc/systemd/system/
sudo systemctl enable payloads.service

echo "[*] Setting up web payload selector service..."
sudo cp payloads/web_selector.service /etc/systemd/system/
sudo systemctl enable web_selector

echo "[*] Creating exfil directory..."
mkdir -p /home/pi/exfil
chown pi:pi /home/pi/exfil
chmod 700 /home/pi/exfil

echo "[*] Setup complete! Reboot your Pi Zero 2 W."