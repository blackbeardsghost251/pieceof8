#!/bin/bash
set -e
cd /sys/kernel/config/usb_gadget/
[ -d pi_composite ] && rm -rf pi_composite
mkdir pi_composite
cd pi_composite

echo 0x1d6b > idVendor
echo 0x0104 > idProduct
echo 0x0100 > bcdDevice
echo 0x0200 > bcdUSB

mkdir -p strings/0x409
echo "deadbeef12345678" > strings/0x409/serialnumber
echo "Pi Zero 2 W" > strings/0x409/manufacturer
echo "Pi HID+RNDIS" > strings/0x409/product

mkdir -p configs/c.1
echo 250 > configs/c.1/MaxPower
mkdir -p configs/c.1/strings/0x409
echo "Config 1: HID+RNDIS" > configs/c.1/strings/0x409/configuration

# HID keyboard
mkdir -p functions/hid.usb0
echo 1 > functions/hid.usb0/protocol
echo 1 > functions/hid.usb0/subclass
echo 8 > functions/hid.usb0/report_length
echo -ne '\x05\x01\x09\x06\xa1\x01\x05\x07\x19\xe0\x29\xe7\x15\x00\x25\x01\x75\x01\x95\x08\x81\x02\x95\x01\x75\x08\x81\x01\x95\x05\x75\x01\x05\x08\x19\x01\x29\x05\x91\x02\x95\x01\x75\x03\x91\x01\x95\x06\x75\x08\x15\x00\x25\x65\x05\x07\x19\x00\x29\x65\x81\x00\xc0' > functions/hid.usb0/report_desc

# RNDIS
mkdir -p functions/rndis.usb0
ln -s functions/hid.usb0 configs/c.1/
ln -s functions/rndis.usb0 configs/c.1/

mkdir -p os_desc
echo "MSFT100" > os_desc/qw_sign
echo 0x0100 > os_desc/b_vendor_code
echo "1" > os_desc/use

UDC=$(ls /sys/class/udc | head -n 1)
echo $UDC > UDC