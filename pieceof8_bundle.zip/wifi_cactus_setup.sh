#!/bin/bash
# WiFi Cactus / BashBunny-style Setup Script for Raspberry Pi Zero 2 W
# Features: SSH, Kismet, Aircrack-ng, Python, payload automation

set -e

echo "[*] Updating system..."
sudo apt update && sudo apt -y upgrade

echo "[*] Installing dependencies: git, python3, pip, screen, etc."
sudo apt -y install git python3 python3-pip python3-venv screen usbutils net-tools

echo "[*] Installing Aircrack-ng and Kismet..."
sudo apt -y install aircrack-ng kismet

echo "[*] Enabling SSH server..."
sudo systemctl enable ssh
sudo systemctl start ssh

echo "[*] Creating payloads directory (like BashBunny)..."
mkdir -p ~/payloads
echo -e "#!/bin/bash\n# Place your automation scripts here!" > ~/payloads/README.txt

echo "[*] Creating systemd service for payload automation..."
cat << 'EOF' | sudo tee /etc/systemd/system/payloads.service > /dev/null
[Unit]
Description=Run WiFi Cactus Payloads at boot
After=network.target

[Service]
Type=simple
User=pi
WorkingDirectory=/home/pi/payloads
ExecStart=/bin/bash /home/pi/payloads/autorun.sh
Restart=no

[Install]
WantedBy=multi-user.target
EOF

echo "[*] Creating autorun.sh example in ~/payloads..."
cat << 'EOF' > ~/payloads/autorun.sh
#!/bin/bash
# Example: Monitor mode on wlan1 and start Kismet
echo "[*] Bringing up wlan1 in monitor mode..."
if ip link show wlan1 > /dev/null 2>&1; then
  sudo ip link set wlan1 down
  sudo iwconfig wlan1 mode monitor
  sudo ip link set wlan1 up
  echo "[*] Starting Kismet server on wlan1..."
  nohup kismet -c wlan1 > /home/pi/payloads/kismet.log 2>&1 &
else
  echo "No wlan1 adapter found; skipping monitor mode/Kismet."
fi
# Add your own automation below
EOF
chmod +x ~/payloads/autorun.sh

echo "[*] Enabling payloads.service..."
sudo systemctl enable payloads.service

echo "[*] Setup complete!"
echo "To add your own scripts, put them in ~/payloads and edit ~/payloads/autorun.sh"
echo "Reboot to test automatic payload execution."