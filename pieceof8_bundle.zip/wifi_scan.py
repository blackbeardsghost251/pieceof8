import subprocess
import datetime

def scan(interface="wlan1"):
    timestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    filename = f"/home/pi/captures/scan_{timestamp}.csv"
    subprocess.run([
        "sudo", "airodump-ng", interface,
        "--output-format", "csv",
        "-w", filename
    ])

if __name__ == "__main__":
    scan()